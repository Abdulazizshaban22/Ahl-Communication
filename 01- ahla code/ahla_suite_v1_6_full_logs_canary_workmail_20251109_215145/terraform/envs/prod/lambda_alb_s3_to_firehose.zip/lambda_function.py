
import boto3, gzip, io, os, json, shlex, datetime
fh = boto3.client('firehose')
STREAM = os.environ.get('FIREHOSE_STREAM')
def parse_line(line):
    try:
        parts = shlex.split(line)
        # ALB log v2 fields (subset)
        rec = {}
        # map indices carefully; tolerate variations
        # ref: https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-access-logs.html#access-log-entry-format
        rec['type'] = parts[0]
        rec['time'] = parts[1]
        rec['elb'] = parts[2]
        client = parts[3].split(':')
        rec['client_ip'] = client[0]
        rec['client_port'] = client[1] if len(client)>1 else None
        target = parts[4].split(':')
        rec['target_ip'] = target[0] if parts[4] != '-' else None
        rec['target_port'] = target[1] if len(target)>1 else None
        rec['request_processing_time'] = float(parts[5])
        rec['target_processing_time'] = float(parts[6])
        rec['response_processing_time'] = float(parts[7])
        rec['elb_status_code'] = int(parts[8])
        rec['target_status_code'] = int(parts[9]) if parts[9] != '-' else None
        rec['received_bytes'] = int(parts[10])
        rec['sent_bytes'] = int(parts[11])
        req = shlex.split(parts[12])[0] if parts[12].startswith('"') else parts[12]
        if req.startswith('"'):
            # already properly captured by shlex at higher level; fallback minimal
            pass
        # request line often separate: "METHOD URL HTTP/x"
        if parts[12].startswith('"'):
            method, url, http = shlex.split(parts[12])
        else:
            method, url, http = parts[12], parts[13], parts[14]
        rec['request_method']=method; rec['request_url']=url; rec['request_http']=http
        # user agent at index 13 or 14; use safe find of quoted segment
        # since shlex already split correctly, UA should be next quoted token
        # find first token with spaces (heuristic)
        for p in parts:
            if 'Mozilla' in p or 'Dalvik' in p or 'okhttp' in p:
                rec['user_agent'] = p.strip('"'); break
        # timestamps
        rec['@timestamp'] = datetime.datetime.fromisoformat(rec['time'].replace('Z','+00:00')).isoformat()
        rec['service'] = 'alb'
        return rec
    except Exception as e:
        return {"parse_error": str(e), "raw": line}

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    total = 0
    for rec in event.get('Records', []):
        b = rec['s3']['bucket']['name']; k = rec['s3']['object']['key']
        obj = s3.get_object(Bucket=b, Key=k)
        body = obj['Body'].read()
        if k.endswith('.gz'):
            body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
        lines = body.decode('utf-8', errors='ignore').splitlines()
        batch=[]
        for line in lines:
            if not line.strip(): continue
            doc = parse_line(line)
            batch.append({'Data': (json.dumps(doc)+'\n').encode('utf-8')})
            if len(batch) >= 500:
                fh.put_record_batch(DeliveryStreamName=STREAM, Records=batch); batch=[]
        if batch:
            fh.put_record_batch(DeliveryStreamName=STREAM, Records=batch)
        total += len(lines)
    return {"ok": True, "count": total}
