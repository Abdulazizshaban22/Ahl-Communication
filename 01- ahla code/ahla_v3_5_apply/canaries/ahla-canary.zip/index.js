
'use strict';
const synthetics = require('Synthetics');
const log = require('SyntheticsLogger');

exports.handler = async () => {
  const page = await synthetics.getPage();
  const url = process.env.TEST_URL || 'https://example.com/';
  const start = Date.now();
  await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
  const dur = Date.now() - start;
  log.info(`Opened ${url} in ${dur}ms`);
  const html = await page.content();
  if (!html || html.length < 100) throw new Error('Page did not load correctly');
};
