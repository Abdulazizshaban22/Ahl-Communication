
import boto3, gzip, io, os, json

fh = boto3.client('firehose')
STREAM = os.environ.get('FIREHOSE_STREAM')

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    for rec in event.get('Records', []):
        b = rec['s3']['bucket']['name']
        k = rec['s3']['object']['key']
        obj = s3.get_object(Bucket=b, Key=k)
        body = obj['Body'].read()
        if k.endswith('.gz'):
            body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
        # ALB logs are text lines; send in batches
        lines = body.decode('utf-8', errors='ignore').splitlines()
        entries = []
        for line in lines:
            if not line.strip(): continue
            entries.append({'Data': (line+'
').encode('utf-8')})
            if len(entries) == 500:
                fh.put_record_batch(DeliveryStreamName=STREAM, Records=entries)
                entries = []
        if entries:
            fh.put_record_batch(DeliveryStreamName=STREAM, Records=entries)
    return {"ok": True, "records": len(lines)}
