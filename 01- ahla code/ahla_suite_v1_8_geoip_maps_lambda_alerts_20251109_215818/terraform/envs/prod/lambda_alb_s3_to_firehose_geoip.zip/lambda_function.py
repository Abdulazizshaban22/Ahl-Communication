
import boto3, gzip, io, os, json, shlex, datetime
try:
    import maxminddb
except Exception:
    maxminddb = None

fh = boto3.client('firehose')
STREAM = os.environ.get('FIREHOSE_STREAM')
DBPATHS = ['/opt/GeoLite2-City.mmdb']

reader = None
if maxminddb:
    for p in DBPATHS:
        if os.path.exists(p):
            reader = maxminddb.open_database(p)
            break

def geo_lookup(ip):
    if not reader: return None
    try:
        rec = reader.get(ip)
        if not rec: return None
        out = {
            "country_name": (rec.get("country",{}).get("names",{}) or {}).get("en"),
            "country_iso_code": rec.get("country",{}).get("iso_code"),
            "city_name": (rec.get("city",{}).get("names",{}) or {}).get("en"),
        }
        loc = rec.get("location",{})
        if "latitude" in loc and "longitude" in loc:
            out["location"] = {"lat": loc["latitude"], "lon": loc["longitude"]}
        return out
    except Exception:
        return None

def parse_line(line):
    parts = shlex.split(line)
    rec = {}
    rec['type'] = parts[0]
    rec['time'] = parts[1]
    rec['elb'] = parts[2]
    client = parts[3].split(':')
    rec['client_ip'] = client[0]
    rec['request_processing_time'] = float(parts[5])
    rec['target_processing_time'] = float(parts[6])
    rec['elb_status_code'] = int(parts[8])
    req = shlex.split(parts[12])
    if len(req)==3:
        rec['request_method'], rec['request_url'], rec['request_http'] = req
    else:
        rec['request_method'] = parts[12]
        rec['request_url'] = parts[13] if len(parts)>13 else None
        rec['request_http'] = parts[14] if len(parts)>14 else None
    rec['@timestamp'] = datetime.datetime.fromisoformat(rec['time'].replace('Z','+00:00')).isoformat()
    rec['service'] = 'alb'
    geo = geo_lookup(rec['client_ip'])
    if geo: rec['ip2geo'] = geo
    return rec

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    total=0
    for r in event.get('Records', []):
        b = r['s3']['bucket']['name']; k = r['s3']['object']['key']
        o = s3.get_object(Bucket=b, Key=k)
        body = o['Body'].read()
        if k.endswith('.gz'):
            body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
        for line in body.decode('utf-8', errors='ignore').splitlines():
            if not line.strip(): continue
            doc = parse_line(line)
            fh.put_record(DeliveryStreamName=STREAM, Record={'Data': (json.dumps(doc)+'\n').encode('utf-8')})
            total+=1
    return {"ok": True, "count": total}
