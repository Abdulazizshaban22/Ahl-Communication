
'use strict';
const WebSocket = require('ws');
exports.handler = async () => {
  const url = process.env.WS_URL || 'wss://app.ahla.example.com/ws';
  return await new Promise((resolve, reject) => {
    const ws = new WebSocket(url, { rejectUnauthorized: true });
    const t = setTimeout(() => reject(new Error('WS timeout')), 15000);
    ws.on('open', () => { clearTimeout(t); ws.close(); resolve(); });
    ws.on('error', (e) => { clearTimeout(t); reject(e); });
  });
};
