
'use strict';
const synthetics = require('Synthetics');
const log = require('SyntheticsLogger');

const url = process.env.TEST_URL || 'https://app.ahla.example.com/';

exports.handler = async () => {
  const page = await synthetics.getPage();

  const start = Date.now();
  await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
  const navTiming = await page.evaluate(() => {
    const [nav] = performance.getEntriesByType('navigation');
    return nav ? { ttfb: nav.responseStart, dom: nav.domContentLoadedEventEnd, load: nav.loadEventEnd } : null;
  });

  const dur = Date.now() - start;
  log.info(`Dur=${dur}ms, navTiming=${JSON.stringify(navTiming)}`);

  // Basic assertion: page contains 'Ahla' (adjust selector/text as needed)
  const content = await page.content();
  if (!content || !content.includes('Ahla')) {
    throw new Error('Keyword "Ahla" not found on page');
  }
};
